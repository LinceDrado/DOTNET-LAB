﻿using StudentManagementAdo.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace StudentManagementAdo.Data
{
    public class StudentRepository
    {
        private readonly string _connectionString;

        public StudentRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // READ ALL
        public List<Student> GetAll()
        {
            var list = new List<Student>();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT * FROM Students";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Student
                    {
                        Stno = Convert.ToInt32(reader["Stno"]),
                        Fname = reader["Fname"].ToString(),
                        Mname = reader["Mname"].ToString(),
                        Lname = reader["Lname"].ToString(),
                        Marks = Convert.ToDecimal(reader["Marks"])
                    });
                }
            }
            return list;
        }

        // READ ONE (by Id)
        public Student GetById(int Stno)
        {
            Student obj = null;
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT * FROM Students WHERE Stno = @Stno";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Stno", Stno);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    obj = new Student
                    {
                        Stno = Convert.ToInt32(reader["Stno"]),
                        Fname = reader["Fname"].ToString(),
                        Mname = reader["Mname"].ToString(),
                        Lname = reader["Lname"].ToString(),
                        Marks = Convert.ToDecimal(reader["Marks"])
                    };
                }
            }
            return obj;
        }

        // CREATE
        public void Insert(Student obj)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"INSERT INTO Students (Stno, Fname, Mname, Lname, Marks)
                                 VALUES (@Stno, @Fname, @Mname, @Lname, @Marks)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Stno", obj.Stno);
                cmd.Parameters.AddWithValue("@Fname", obj.Fname);
                cmd.Parameters.AddWithValue("@Mname", obj.Mname);
                cmd.Parameters.AddWithValue("@Lname", obj.Lname);
                cmd.Parameters.AddWithValue("@Marks", obj.Marks);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // UPDATE
        public void Update(Student obj)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"UPDATE Students 
                                 SET Fname=@Fname, Mname=@Mname, Lname=@Lname, Marks=@Marks
                                 WHERE Stno=@Stno";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Stno", obj.Stno);
                cmd.Parameters.AddWithValue("@Fname", obj.Fname);
                cmd.Parameters.AddWithValue("@Mname", obj.Mname);
                cmd.Parameters.AddWithValue("@Lname", obj.Lname);
                cmd.Parameters.AddWithValue("@Marks", obj.Marks);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // DELETE
        public void Delete(int Stno)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "DELETE FROM Students WHERE Stno=@Stno";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Stno", Stno);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
