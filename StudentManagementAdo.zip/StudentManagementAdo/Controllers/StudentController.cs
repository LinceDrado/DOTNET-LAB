﻿using Microsoft.AspNetCore.Mvc;
using StudentManagementAdo.Data;
using StudentManagementAdo.Models;

namespace StudentManagementAdo.Controllers
{
    public class StudentController : Controller
    {
        private readonly StudentRepository _repo;

        public StudentController(StudentRepository repo)
        {
            _repo = repo;
        }

        // LIST
        public IActionResult Index()
        {
            var data = _repo.GetAll();
            return View(data);
        }

        // CREATE - GET
        public IActionResult Create() => View();

        // CREATE - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Student obj)
        {
            if (ModelState.IsValid)
            {
                _repo.Insert(obj);
                return RedirectToAction("Index");
            }
            return View(obj);
        }

        // EDIT - GET
        public IActionResult Edit(int Stno)
        {
            var obj = _repo.GetById(Stno);
            if (obj == null) return NotFound();
            return View(obj);
        }

        // EDIT - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Student obj)
        {
            if (ModelState.IsValid)
            {
                _repo.Update(obj);
                return RedirectToAction("Index");
            }
            return View(obj);
        }

        // DELETE - GET (confirmation page)
        public IActionResult Delete(int id)
        {
            var obj = _repo.GetById(id);
            if (obj == null) return NotFound();
            return View(obj);
        }

        // DELETE - POST
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            _repo.Delete(id);
            return RedirectToAction("Index");
        }
    }
}
