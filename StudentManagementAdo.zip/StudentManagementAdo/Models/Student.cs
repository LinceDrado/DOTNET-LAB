﻿using System.ComponentModel.DataAnnotations;

namespace StudentManagementAdo.Models
{
    public class Student
    {
        [Key]
        public int Stno { get; set; }

        [Required(ErrorMessage = "First name is required")]
        public string Fname { get; set; }

        [Required]
        public string Mname { get; set; }

        [Required]
        public string Lname { get; set; }

        [Required]
        [Range(0.00, 100.00)]
        public decimal Marks { get; set; }
    }
}
