﻿using System.ComponentModel.DataAnnotations;

namespace StudentManagementAdo.Models
{
    public class Student
    {
        [Key]
        public int Stno { get; set; }

        [Required(ErrorMessage = "First name is required")]
        public string Fname { get; set; }

        [Required]
        public string Mname { get; set; }

        [Required]
        public string Lname { get; set; }

        [Required]
        [Range(0.00, 100.00)]
        public decimal Marks { get; set; }
    }
}

//using System;
//using System.ComponentModel.DataAnnotations;

//namespace YourProject.Models
//{
//    public class Employee
//    {
//        [Required(ErrorMessage = "Employee Number is required")]
//        [Range(1, 999999, ErrorMessage = "Employee Number must be positive")]
//        public int Eno { get; set; }

//        [Required(ErrorMessage = "Employee Name is required")]
//        [StringLength(50, MinimumLength = 3,
//            ErrorMessage = "Name must be between 3 and 50 characters")]
//        [RegularExpression(@"^[A-Za-z\s]+$",
//            ErrorMessage = "Name can contain only letters and spaces")]
//        public string Ename { get; set; }

//        [Required(ErrorMessage = "Date of Joining is required")]
//        [DataType(DataType.Date)]
//        public DateTime? Doj { get; set; }

//        [Required(ErrorMessage = "Salary is required")]
//        [Range(1000, 1000000,
//            ErrorMessage = "Salary must be between 1,000 and 10,00,000")]
//        public decimal? Salary { get; set; }
//    }
//}
