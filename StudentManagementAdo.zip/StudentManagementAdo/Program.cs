using StudentManagementAdo.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<StudentRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseRouting();

app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Student}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();


//CREATE DATABASE StudentDB;
//GO
//USE StudentDB;
//GO
//CREATE TABLE students(
//	Stno INT PRIMARY KEY,
//    Fname NVARCHAR(30) NOT NULL,
//    Mname NVARCHAR(30) NOT NULL,
//    Lname NVARCHAR(30) NOT NULL,
//    Marks DECIMAL(5,2) NOT NULL
//);
